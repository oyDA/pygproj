import pygame
import sys
import os


pygame.init()

def main():
    pygame.init()
    clock = pygame.time.Clock()
    fps = 60
    size = [350, 226]
    bg = [80, 200, 120]
    pygame.display.set_caption('Main Menu')
    screen = pygame.display.set_mode(size)

    snake_btn = pygame.Rect(0, 0, 350, 55)
    tetris_btn = pygame.Rect(0, 57, 350, 55)
    ark_btn = pygame.Rect(0, 114, 350, 55)
    sm_btn = pygame.Rect(0, 171, 350, 55)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if snake_btn.collidepoint(mouse_pos):
                    os.system('python main_snake.py')
                if tetris_btn.collidepoint(mouse_pos):
                    os.system('python main_tetris.py')
                if ark_btn.collidepoint(mouse_pos):
                    os.system('python main_arkanoid.py')
                if sm_btn.collidepoint(mouse_pos):
                    os.system('python sm.py')

        screen.fill(bg)

        pygame.draw.rect(screen, [0, 77, 87], snake_btn)
        pygame.draw.rect(screen, [0, 77, 87], tetris_btn)
        pygame.draw.rect(screen, [0, 77, 87], ark_btn)
        pygame.draw.rect(screen, [0, 77, 87], sm_btn)

        f1 = pygame.font.Font('font1.ttf', 55)
        text1 = f1.render('Snake', 1, (80, 200, 120))
        text2 = f1.render('Tetris', 1, (80, 200, 120))
        text3 = f1.render('Arkanoid', 1, (80, 200, 120))
        text4 = f1.render('Mario', 1, (80, 200, 120))

        screen.blit(text1, (85, -25))
        screen.blit(text2, (87, 31))
        screen.blit(text3, (41, 89))
        screen.blit(text4, (96, 147))

        pygame.display.update()
        clock.tick(fps)

    pygame.quit()
    sys.exit


if __name__ == '__main__':
    main()